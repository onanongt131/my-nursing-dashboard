'use client';
import React, { useState } from 'react';
import { createPortal } from 'react-dom';
import {requiresReview,reviewMonth} from '@/lib/review/period';
import PendingRecordEditor from '@/components/PendingRecordEditor';
import {wpSpecialCriteria,type WpFormType} from '@/lib/wpSpecialCriteria';
import IvCareFactorDetails from '@/components/IvCareFactorDetails';
import { lrAuditGroups } from '@/lib/lrAuditCriteria';
import { specialUnitAuditForms, isSpecialUnitForm, groupSection } from '@/lib/specialUnitAuditForms';
import { CheckCircleIcon, XMarkIcon } from '@heroicons/react/24/solid';
interface BatchItem {
  id?: string | number;
  source_table?: string;
  wp_id?: string;
  wp_name?: string;
  total_evaluated?: number;
  total_practiced?: number;
  unpracticed_reasons?: string | null;
  ama_count?: number | null;
  total_discharges?: number | null;
  hn?: string;
  an?: string;
  admit_date?: string;
  admit_diagnosis?: string;
  previous_discharge_date?: string;
  discharge_ward?: string;
  cause_patient?: string;
  cause_discharge_planning?: string;
  cause_disease_condition?: string;
  fall_date?: string;
  incident_date?: string;
  severity?: string;
  detail?: string;
  description?: string;
  discharge_date?: string;
  treatment_right?: string;
  ama_reason?: string;
  reason?: string;
  cause?: string;
  record_date?: string;
  complication?: string;
  issue?: string;
  grade?: string | number;
  site?: string;
  route?: string;
  factor_drug?: string;
  factor_patient?: string;
  factor_personnel?: string;
  audit_month?: string;
  month?: string;
  total_infusion_days?: number;
  total_sites?: number;
  total_punctures?: number;
  first_attempt_punctures?: number;
  total_falls?: number;
  fall_count?: number;
  total_cases?: number;
  note?: string;
  fiscal_year?: string | number;
  patient_days?: number;
  status?: string;
  [key: string]: any;
}
interface BatchGroup {
  type: string;
  audit_month: string;
  items: BatchItem[];
  auditor_name?: string;
  evaluator?: string;
  department_id?: number | string;
}
interface BatchDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  batchGroup: BatchGroup | null;
  departmentName: string;
  canApprove: boolean;
  onApprove: (type: string, audit_month: string) => void;
  onApproveSingle?: (item: BatchItem) => void;
}
function auditNotes(item: BatchItem | null) {
  const byQuestion = new Map<string, string>();
  const sectionNotes = new Map<number, string>();
  if (!item) return {byQuestion, sectionNotes};
  for (let section = 1; section <= 5; section++) {
    const value = item['s' + section + '_notes'];
    if (typeof value !== 'string' || !value.trim()) continue;
    const parts = value.split(/(?:^|\r?\n)(s[1-5]_[a-z0-9_]+):[ \t]*/i);
    if (parts[0].trim()) sectionNotes.set(section, parts[0].trim());
    for (let i = 1; i < parts.length; i += 2) {
      byQuestion.set(parts[i].toLowerCase(), parts[i + 1].trim());
    }
  }
  return {byQuestion, sectionNotes};
}

export default function BatchDetailModal({
  isOpen,
  onClose,
  batchGroup,
  departmentName,
  canApprove,
  onApprove,
  onApproveSingle
}: BatchDetailModalProps) {
  const [editing,setEditing]=useState<BatchItem|null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedAuditItem, setSelectedAuditItem] = useState<BatchItem | null>(null);
  if (!isOpen || !batchGroup) return null;
  batchGroup={...batchGroup,items:batchGroup.items.filter(item=>requiresReview(item))};
  if(!batchGroup.items.length)return <div className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/50"><div className="rounded-xl bg-white p-6">ข้อมูลก่อนปีงบประมาณ 2570 ไม่ต้องอนุมัติ<button onClick={onClose} className="ml-4 rounded border p-2">ปิด</button></div></div>;
  if (batchGroup.items.some(item => item.source_table === 'nso_special_audits') || batchGroup.type.toLowerCase() === 'audit_lr') {
    return <SpecialLRBatchReview batchGroup={batchGroup} departmentName={departmentName} canApprove={canApprove} onClose={onClose} onApprove={onApprove} />;
  }
  const typeLower = batchGroup.type.toLowerCase();
  const isNursingChartAudit = typeLower.includes('audit') || typeLower.includes('nursing_chart');
  const isWpQa = typeLower.includes('wp') || typeLower.includes('qa');
  const isReadmit = typeLower.includes('readmit');
  const isFall = typeLower.includes('fall');
  const isFallSummary = isFall && typeLower.includes('summary');
  const isAma = typeLower.includes('ama');
  const canEdit = (item: BatchItem) => item.id != null && requiresReview(item) && ['pending', 'draft'].includes(item.status || '');
  const editButton = (item: BatchItem) => canEdit(item) ? (
    <button type="button" onClick={() => setEditing(item)}
      className="whitespace-nowrap rounded-lg border border-teal-600 px-3 py-1 text-xs font-bold text-teal-800 hover:bg-teal-50">
      แก้ไข
    </button>
  ) : <span className="text-slate-400">—</span>;
  const notes = auditNotes(selectedAuditItem);
  const questionNote = (key: string) => selectedAuditItem?.[key + '_note'] || notes.byQuestion.get(key) || '—';
  const sectionNote = (section: number) => notes.sectionNotes.has(section) && (
    <div className="whitespace-pre-wrap break-words rounded-lg bg-amber-50 p-3">
      <strong>หมายเหตุหมวด {section}</strong><p>{notes.sectionNotes.get(section)}</p>
    </div>
  );
  const isIvCare = typeLower.includes('iv');
  const isIvCareSummary = isIvCare && typeLower.includes('summary');
  const isSummaryData = isFallSummary || isIvCareSummary || typeLower.includes('summary');
  const getTargetTable = (type: string): string => {
  const source=batchGroup.items[0]?.source_table;
  if(source&&['nursing_chart_audits','wp_qa_records','nso_special_wp_records','iv_care_complications','iv_care_monthly_summaries','fall_incident_records','fall_monthly_summary','readmit_incident_records','readmit_monthly_summary','ama_incident_records','ama_monthly_summary'].includes(source))return source;
  const t = type.toLowerCase();
  if (t==='audit'||t.includes('nursing_chart')) return 'nursing_chart_audits';
  if (t.includes('wp') || t.includes('qa')) return 'wp_qa_records';
  if (t.includes('readmit')) {
    return t.includes('summary') ? 'readmit_monthly_summary' : 'readmit_incident_records';
  }
  if (t.includes('fall')) {
    return t.includes('summary') ? 'fall_monthly_summary' : 'fall_incident_records';
  }
  if (t.includes('iv')) {
    return t.includes('summary') ? 'iv_care_monthly_summaries' : 'iv_care_complications';
  }
  if (t.includes('ama')) {
    return t.includes('summary') ? 'ama_monthly_summary' : 'ama_incident_records';
  }
  return 'nursing_chart_audits'; // Default fallback
};
  const approveItems = async (items: BatchItem[]) => {
    const table = getTargetTable(batchGroup.type);
    const ids = items.map(item => item.id);
    if (!items.length || items.some(item => item.id == null || (item.source_table && item.source_table !== table))) {
      throw new Error('ไม่พบรหัสรายการหรือมีรายการจากคนละตาราง กรุณาโหลดใหม่');
    }
    const response = await fetch('/api/readmit-ama-approve', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({table, ids}),
    });
    const result = await response.json().catch(() => null);
    if (!response.ok || result?.approved !== new Set(ids.map(String)).size) {
      throw new Error(result?.error || 'ยังยืนยันการบันทึกสถานะไม่ได้ กรุณาโหลดรายการใหม่');
    }
  };

  const handleApproval = async (item?: BatchItem) => {
    if (!canApprove || loading) return;
    if (!item && !confirm('ยืนยันอนุมัติรายการชุดนี้ทั้งหมดหรือไม่?')) return;
    setLoading(true);
    try {
      await approveItems(item ? [item] : batchGroup.items);
      alert(item ? 'อนุมัติรายการนี้สำเร็จ' : 'อนุมัติสำเร็จ');
      setSelectedAuditItem(null);
      onApprove(batchGroup.type, batchGroup.audit_month);
      onClose();
    } catch (error) {
      alert(error instanceof Error ? error.message : 'อนุมัติไม่สำเร็จ กรุณาลองใหม่');
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-6xl w-full p-6 space-y-5 shadow-2xl relative max-h-[90vh] flex flex-col">
        {/* หัวข้อ Modal หลัก */}
        <div className="flex justify-between items-center border-b pb-3">
          <div>
            <span className="text-xs font-bold text-emerald-600 uppercase">
              รายละเอียดผลการประเมิน ({batchGroup.type.toUpperCase()})
            </span>
            <h3 className="text-lg font-bold text-gray-900">ประจำเดือน / วันที่: {reviewMonth(batchGroup.items[0]||{})||batchGroup.audit_month}</h3>
          </div>
          <button 
            onClick={onClose} 
            disabled={loading}
            className="text-gray-400 hover:text-gray-600 bg-gray-100 hover:bg-gray-200 p-2 rounded-full transition cursor-pointer"
          >
            <XMarkIcon className="w-5 h-5" />
          </button>
        </div>
        {/* ข้อมูลสรุปย่อ */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm bg-gray-50 p-4 rounded-xl border border-gray-200">
          <div><span className="font-semibold text-gray-500">หน่วยงาน:</span> {departmentName}</div>
          <div><span className="font-semibold text-gray-500">ผู้ประเมิน:</span> {batchGroup.auditor_name || batchGroup.evaluator || '-'}</div>
          <div><span className="font-semibold text-gray-500">สถานะรวม:</span> <span className="text-amber-600 font-bold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">รออนุมัติ</span></div>
        </div>
        {!isNursingChartAudit && !isWpQa && !isAma && !isReadmit && <div className="flex flex-wrap gap-2">{batchGroup.items.filter(canEdit).map((item,index)=><button key={String(item.id||index)} type="button" onClick={()=>setEditing(item)} className="rounded-lg border border-teal-600 px-3 py-2 text-sm font-bold text-teal-800">แก้ไขรายการ {index+1}{item.hn?' · HN '+item.hn:''}</button>)}</div>}
        {editing&&<PendingRecordEditor table={editing.source_table||getTargetTable(batchGroup.type)} id={editing.id!} onClose={()=>setEditing(null)} onSaved={()=>{setEditing(null);onApprove(batchGroup.type,batchGroup.audit_month);onClose();}}/>}
        {/* ตารางแสดงรายการ */}
        <div className="space-y-2 flex-1 overflow-hidden flex flex-col">
          <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider">
            รายการข้อมูล ({batchGroup.items.length} รายการ)
          </h4>
          <div className="border border-gray-200 rounded-xl overflow-y-auto flex-1 max-h-96">
            {batchGroup.items.some(item=>item.source_table==='nso_special_wp_records') ? (
              <div className="space-y-4 p-3">{batchGroup.items.map((item,index)=><section key={String(item.id||index)} className="rounded-xl border p-3"><h4 className="mb-2 font-bold text-teal-900">รายการ {index+1} · {item.auditor_name||'-'} · {item.audit_month}</h4><table className="w-full text-left text-xs"><thead><tr><th className="p-2">ข้อประเมิน</th><th className="p-2">ประเมิน</th><th className="p-2">ปฏิบัติ</th><th className="p-2">เหตุผล / หมายเหตุ</th><th className="p-2 text-center">แก้ไข</th></tr></thead><tbody>{Object.entries(item.answers||{}).filter(([key])=>key!=='_general_note').map(([key,value],rowIndex,answers)=>{const a=value as {total_evaluated?:number;total_practiced?:number;unpracticed_reasons?:string};const label=wpSpecialCriteria[item.form_type as WpFormType]?.flatMap(g=>g.items).find(i=>i.id===key)?.label||key;return <tr key={key} className="border-t"><td className="p-2">{label}</td><td className="p-2">{a.total_evaluated}</td><td className="p-2">{a.total_practiced}</td><td className="whitespace-pre-wrap p-2">{a.unpracticed_reasons||'—'}</td>{rowIndex===0&&<td rowSpan={answers.length} className="p-2 text-center align-top">{editButton(item)}</td>}</tr>;})}</tbody></table>{typeof item.answers?._general_note==='string'&&<p className="mt-2 whitespace-pre-wrap text-sm">หมายเหตุ: {item.answers._general_note}</p>}</section>)}</div>
            ) : isWpQa ? (
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-emerald-100 text-emerald-900 sticky top-0 z-10">
                  <tr>
                    <th className="p-2.5">รหัส WP</th>
                    <th className="p-2.5">หัวข้อ WP</th>
                    <th className="p-2.5 text-center">ประเมินแล้ว</th>
                    <th className="p-2.5 text-center">ปฏิบัติจริง</th>
                    <th className="p-2.5">สิ่งที่ไม่ได้ปฏิบัติ / หมายเหตุ</th>
                    <th className="p-2.5 text-center">แก้ไข</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50">
                      <td className="p-2.5 font-bold text-emerald-800">{item.wp_id}</td>
                      <td className="p-2.5 text-gray-800">{item.wp_name}</td>
                      <td className="p-2.5 text-center font-semibold">{item.total_evaluated}</td>
                      <td className="p-2.5 text-center font-semibold text-emerald-600">{item.total_practiced}</td>
                      <td className="whitespace-pre-wrap break-words p-2.5">{item.unpracticed_reasons || '—'}</td>
                      <td className="p-2.5 text-center">{editButton(item)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : isReadmit && isSummaryData ? (
              <table className="w-full border-collapse text-left text-xs">
                <thead className="sticky top-0 z-10 bg-teal-100 text-teal-900">
                  <tr>
                    <th className="p-2.5">เดือน</th>
                    <th className="p-2.5 text-center">จำนวน Re-admit</th>
                    <th className="p-2.5 text-center">ยอดจำหน่ายเดือนที่แล้ว</th>
                    <th className="p-2.5 text-center">แก้ไข</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, index) => (
                    <tr key={item.id ?? index}>
                      <td className="p-2.5">{reviewMonth(item) ?? '—'}</td>
                      <td className="p-2.5 text-center tabular-nums">{item.readmit_count ?? '—'}</td>
                      <td className="p-2.5 text-center tabular-nums">{item.prev_month_discharges ?? '—'}</td>
                      <td className="p-2.5 text-center">{editButton(item)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : isReadmit ? (
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-teal-100 text-teal-900 sticky top-0 z-10">
                  <tr>
                    <th className="p-2.5 text-center">ลำดับ</th>
                    <th className="p-2.5">HN</th>
                    <th className="p-2.5">AN</th>
                    <th className="p-2.5">วันที่ Admit</th>
                    <th className="p-2.5">การวินิจฉัยโรคแรกรับ</th>
                    <th className="p-2.5">วันที่จำหน่ายเดิม</th>
                    <th className="p-2.5">หอผู้ป่วยเดิม</th>
                    <th className="p-2.5">สาเหตุ (ผู้ป่วย)</th>
                    <th className="p-2.5">สาเหตุ (D/C Plan)</th>
                    <th className="p-2.5">สาเหตุ (ตัวโรค)</th>
                    <th className="p-2.5 text-center">แก้ไข</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50">
                      <td className="p-2.5 text-center font-bold">{idx + 1}</td>
                      <td className="p-2.5 font-semibold text-teal-800">{item.hn || '-'}</td>
                      <td className="p-2.5">{item.an || '-'}</td>
                      <td className="p-2.5">{item.admit_date || '-'}</td>
                      <td className="p-2.5 text-gray-800">{item.admit_diagnosis || '-'}</td>
                      <td className="p-2.5">{item.previous_discharge_date || '-'}</td>
                      <td className="p-2.5">{item.discharge_ward || '-'}</td>
                      <td className="p-2.5 font-medium text-emerald-700">{item.cause_patient || '-'}</td>
                      <td className="p-2.5 font-medium text-blue-700">{item.cause_discharge_planning || '-'}</td>
                      <td className="p-2.5 font-medium text-purple-700">{item.cause_disease_condition || '-'}</td>
                      <td className="p-2.5 text-center">{editButton(item)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : isFall && !isFallSummary ? (
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-amber-100 text-amber-900 sticky top-0 z-10">
                  <tr>
                    <th className="p-2.5 text-center">ลำดับ</th>
                    <th className="p-2.5">HN</th>
                    <th className="p-2.5">AN</th>
                    <th className="p-2.5">วันที่เกิดเหตุ</th>
                    <th className="p-2.5">ระดับความรุนแรง</th>
                    <th className="p-2.5">รายละเอียดเหตุการณ์</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50">
                      <td className="p-2.5 text-center font-bold">{idx + 1}</td>
                      <td className="p-2.5 font-semibold text-amber-800">{item.hn || '-'}</td>
                      <td className="p-2.5">{item.an || '-'}</td>
                      <td className="p-2.5">{item.fall_date || item.incident_date || '-'}</td>
                      <td className="p-2.5 font-bold text-red-600">{item.severity || '-'}</td>
                      <td className="p-2.5 text-gray-800">{item.detail || item.description || '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : isAma && isSummaryData ? (
              <table className="w-full border-collapse text-left text-xs">
                <thead className="sticky top-0 z-10 bg-rose-100 text-rose-900">
                  <tr>
                    <th className="p-2.5">เดือน</th>
                    <th className="p-2.5 text-center">จำนวนไม่สมัครอยู่</th>
                    <th className="p-2.5 text-center">จำนวนจำหน่าย</th>
                    <th className="p-2.5 text-center">แก้ไข</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, idx) => (
                    <tr key={item.id ?? idx} className="hover:bg-gray-50">
                      <td className="p-2.5 font-semibold">{reviewMonth(item) ?? '—'}</td>
                      <td className="p-2.5 text-center tabular-nums">{item.ama_count ?? '—'}</td>
                      <td className="p-2.5 text-center tabular-nums">{item.total_discharges ?? '—'}</td>
                      <td className="p-2.5 text-center">{editButton(item)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : isAma ? (
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-rose-100 text-rose-900 sticky top-0 z-10">
                  <tr>
                    <th className="p-2.5 text-center">ลำดับ</th>
                    <th className="p-2.5">HN</th>
                    <th className="p-2.5">AN</th>
                    <th className="p-2.5">วันที่เกิดเหตุ</th>
                    <th className="p-2.5">สิทธิการรักษา</th>
                    <th className="p-2.5">สาเหตุที่ไม่สมัครอยู่</th>
                    <th className="p-2.5 text-center">แก้ไข</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50">
                      <td className="p-2.5 text-center font-bold">{idx + 1}</td>
                      <td className="p-2.5 font-semibold text-rose-800">{item.hn || '-'}</td>
                      <td className="p-2.5">{item.an || '-'}</td>
                      <td className="p-2.5">{item.incident_date || item.discharge_date || '-'}</td>
                      <td className="p-2.5">{item.treatment_right || '-'}</td>
                      <td className="p-2.5 font-medium text-gray-800">{item.ama_reason || item.reason || item.cause || '-'}</td>
                      <td className="p-2.5 text-center">{editButton(item)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : isIvCare && !isIvCareSummary ? (
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-cyan-100 text-cyan-900 sticky top-0 z-10">
                  <tr>
                    <th className="p-2.5 text-center">ลำดับ</th>
                    <th className="p-2.5">วันที่บันทึก</th>
                    <th className="p-2.5">HN / AN</th>
                    <th className="p-2.5">ภาวะแทรกซ้อน / Grade</th>
                    <th className="p-2.5">ตำแหน่ง / Route</th>
                    <th className="p-2.5">ปัจจัยเสี่ยง / รายละเอียด</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50 align-top">
                      <td className="p-2.5 text-center font-bold">{idx + 1}</td>
                      <td className="p-2.5 font-semibold text-gray-700">
                        {item.record_date || item.incident_date || '-'}
                      </td>
                      <td className="p-2.5">
                        <div className="font-bold text-cyan-800">{item.hn ? `HN: ${item.hn}` : '-'}</div>
                        <div className="text-gray-500 text-[11px]">{item.an ? `AN: ${item.an}` : ''}</div>
                      </td>
                      <td className="p-2.5">
                        <div className="font-bold text-red-600">{item.complication || item.issue || '-'}</div>
                        {item.grade && (
                          <span className="inline-block mt-1 px-2 py-0.5 bg-red-50 text-red-700 border border-red-200 rounded font-bold text-[10px]">
                            Grade {item.grade}
                          </span>
                        )}
                      </td>
                      <td className="p-2.5">
                        <div className="font-medium text-gray-800">{item.site ? `ตำแหน่ง: ${item.site}` : '-'}</div>
                        <div className="text-gray-500 text-[11px]">{item.route ? `Route: ${item.route}` : ''}</div>
                      </td>
                      <td className="min-w-72 p-2.5 text-gray-600">
                        <IvCareFactorDetails value={item.contributing_factors} legacy={item}/>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : isSummaryData ? (
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-cyan-100 text-cyan-900 sticky top-0 z-10">
                  <tr>
                    <th className="p-2.5 text-center">ลำดับ</th>
                    <th className="p-2.5">ประจำเดือน / งวด</th>
                    {isIvCareSummary ? (
                      <>
                        <th className="p-2.5 text-center">วันให้น้ำเกลือรวม (Infusion Days)</th>
                        <th className="p-2.5 text-center">ตำแหน่งเปิดเส้นรวม (Total Sites)</th>
                        <th className="p-2.5 text-center">จำนวนครั้งแทงเข็มรวม (Total Punctures)</th>
                        <th className="p-2.5 text-center">แทงครั้งเดียวสำเร็จ (1st Attempt)</th>
                      </>
                    ) : isFallSummary ? (
                      <>
                        <th className="p-2.5 text-center">วันนอนรวม (Patient Days)</th>
                        <th className="p-2.5 text-center">จำนวนครั้งที่พลัดตกหกล้ม (Total Falls)</th>
                        <th className="p-2.5">ระดับความรุนแรงรวม / รายละเอียด</th>
                      </>
                    ) : (
                      <>
                        <th className="p-2.5">ปีงบประมาณ</th>
                        <th className="p-2.5 text-center">วันนอนผู้ป่วย (Patient Days)</th>
                      </>
                    )}
                    <th className="p-2.5 text-center">สถานะ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50">
                      <td className="p-2.5 text-center font-bold">{idx + 1}</td>
                      <td className="p-2.5 font-semibold text-cyan-900">{item.audit_month || item.month || '-'}</td>
                      {isIvCareSummary ? (
                        <>
                          <td className="p-2.5 text-center font-semibold text-gray-800">{item.total_infusion_days ?? '-'}</td>
                          <td className="p-2.5 text-center font-semibold text-gray-800">{item.total_sites ?? '-'}</td>
                          <td className="p-2.5 text-center font-semibold text-gray-800">{item.total_punctures ?? '-'}</td>
                          <td className="p-2.5 text-center font-semibold text-emerald-600">{item.first_attempt_punctures ?? '-'}</td>
                        </>
                      ) : isFallSummary ? (
                        <>
                          <td className="p-2.5 text-center font-bold text-blue-600">
                            {item.patient_days !== undefined ? item.patient_days.toLocaleString() : '-'}
                          </td>
                          <td className="p-2.5 text-center font-bold text-amber-700">{item.total_falls ?? item.fall_count ?? item.total_cases ?? '-'}</td>
                          <td className="p-2.5 text-gray-700">{item.detail || item.description || item.note || '-'}</td>
                        </>
                      ) : (
                        <>
                          <td className="p-2.5 font-semibold text-gray-700">{item.fiscal_year || '-'}</td>
                          <td className="p-2.5 text-center font-bold text-blue-600">
                            {item.patient_days !== undefined ? item.patient_days.toLocaleString() : '-'}
                          </td>
                        </>
                      )}
                      <td className="p-2.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.status === 'approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}>
                          {item.status || 'pending'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : isNursingChartAudit ? (
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-indigo-100 text-indigo-900 sticky top-0 z-10">
                  <tr>
                    <th className="p-2.5 text-center">ลำดับ</th>
                    <th className="p-2.5">ประจำเดือน / งวด</th>
                    <th className="p-2.5">HN ผู้ป่วย / วันที่ประเมิน</th>
                    <th className="p-2.5 text-center">สถานะ</th>
                    <th className="p-2.5 text-center">รายละเอียด</th>
                    <th className="p-2.5 text-center">แก้ไข</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {batchGroup.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-gray-50">
                      <td className="p-2.5 text-center font-bold">{idx + 1}</td>
                      <td className="p-2.5 font-semibold text-indigo-900">{item.audit_month || item.month || '-'}</td>
                      <td className="p-2.5 text-gray-700">
                        HN: <span className="font-bold">{item.patient_hn || item.hn || '-'}</span> (วันที่: {item.audit_date || '-'})
                      </td>
                      <td className="p-2.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${item.status === 'approved' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'}`}>
                          {item.status || 'pending'}
                        </span>
                      </td>
                      <td className="p-2.5 text-center">
                        <button 
                          onClick={() => setSelectedAuditItem(item)} 
                          className="px-2.5 py-1 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded text-[11px] font-semibold cursor-pointer"
                        >
                          ดูรายละเอียด
                        </button>
                      </td>
                      <td className="p-2.5 text-center">{editButton(item)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : null}
          </div>
        </div>
        {/* ปุ่มปิดและอนุมัติทั้งหมดด้านล่าง */}
        <div className="flex justify-between items-center pt-4 border-t">
          <button onClick={onClose} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-sm font-bold transition cursor-pointer">
            ปิดหน้าต่าง
          </button>
          {canApprove && (
            <button onClick={() => void handleApproval()} disabled={loading} className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-bold shadow transition flex items-center gap-1.5 cursor-pointer">
              <CheckCircleIcon className="w-5 h-5" />
              <span>อนุมัติรายการชุดนี้ทั้งหมด</span>
            </button>
          )}
        </div>
      </div>
      {/* ========================================================= */}
      {/* Sub-Modal: แสดงฟอร์มรายละเอียดรายข้อ พร้อมคะแนนครบทุกหมวด (1-5) */}
      {/* ========================================================= */}
      {selectedAuditItem && (
        <div className="fixed inset-0 bg-black/60 z-60 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-3xl w-full p-6 space-y-4 shadow-2xl relative max-h-[85vh] flex flex-col">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="text-md font-bold text-gray-800">
                📝 ฟอร์มรายละเอียดคะแนนประเมิน (HN: {selectedAuditItem.patient_hn || selectedAuditItem.hn || '-'})
              </h3>
              <button 
                onClick={() => setSelectedAuditItem(null)}
                className="text-gray-400 hover:text-gray-600 bg-gray-100 p-1.5 rounded-full cursor-pointer"
              >
                <XMarkIcon className="w-5 h-5" />
              </button>
            </div>
            {/* ส่วนแสดงคะแนนรายข้อจัดกลุ่มตามฟอร์ม */}
            <div className="space-y-6 overflow-y-auto flex-1 pr-2 text-xs">
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 grid grid-cols-2 gap-2 text-gray-700">
                <div><strong>ผู้ประเมิน:</strong> {selectedAuditItem.auditor_name || '-'}</div>
                <div><strong>วันที่ประเมิน:</strong> {selectedAuditItem.audit_date || '-'}</div>
                <div><strong>งวดประจำเดือน:</strong> {selectedAuditItem.audit_month || '-'}</div>
                <div><strong>สถานะรายการ:</strong> <span className="font-bold text-amber-600">{selectedAuditItem.status || 'pending'}</span></div>
              </div>
              {/* ================= หมวดที่ 1 ================= */}
              <div className="space-y-4">
                <h3 className="font-bold text-gray-900 text-sm border-b-2 border-emerald-600 pb-1.5 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                  1. การประเมินแรกรับ
                </h3>
                {(() => {
                  const formStructure1 = [
                    {
                      sectionTitle: '1.1 การประเมิน (Assessment)',
                      items: [
                        { key: 's1_1_1', label: '1.1.1 ระบุวันเวลาที่รับไว้ในความดูแล' },
                        { key: 's1_1_2', label: '1.1.2 บอกถึงข้อมูลสำคัญ และระยะเวลาที่ปรากฏอาการ' },
                        { key: 's1_1_3', label: '1.1.3 มีข้อมูลประวัติการเจ็บป่วยปัจจุบัน ที่บอกปัญหา/สาเหตุ สุขภาพที่ปรากฏอย่างชัดเจน' },
                        { key: 's1_1_4', label: '1.1.4 มีข้อมูลการเจ็บป่วยในอดีต ที่มีความสัมพันธ์เกี่ยวข้อง/มีผลต่อการเจ็บป่วย/ปัญหาสุขภาพ' },
                        { key: 's1_1_5', label: '1.1.5 มีข้อมูล การตรวจร่างกาย ในระบบที่เกี่ยวข้องทั้งด้านร่างกาย จิตใจ อารมณ์ สังคม ที่สอดคล้องกับอาการสำคัญ และประวัติการเจ็บป่วย' },
                        { key: 's1_1_6', label: '1.1.6 มีข้อมูลอาการ/อาการแสดงเมื่อแรกรับ ที่เพียงพอที่จะบอกถึงปัญหาสุขภาพ' },
                      ]
                    },
                    {
                      sectionTitle: '1.2 การวางแผน (Planning)',
                      items: [
                        { key: 's1_2_1', label: '1.2.1 การช่วยเหลือ จัดการ แก้ไข/บรรเทา ปัญหา/ภาวะฉุกเฉิน' },
                        { key: 's1_2_2', label: '1.2.2 การวางแผนจำหน่าย หรือส่งต่ออย่างต่อเนื่อง' },
                        { key: 's1_2_3', label: '1.2.3 การป้องกันภาวะแทรกซ้อน หรือ ความเสี่ยงที่มีโอกาสเกิดขึ้น' },
                        { key: 's1_2_4', label: '1.2.4 การเฝ้าระวัง อาการ/อาการแสดง ที่สำคัญ สอดคล้องกับปัญหาสุขภาพด้วยความถี่ที่เหมาะสม' },
                        { key: 's1_2_5', label: '1.2.5 การให้ข้อมูลที่สำคัญ/จำเป็นแก่ผู้ป่วย/ผู้ใช้บริการ และญาติ' },
                      ]
                    },
                    {
                      sectionTitle: '1.3 การนำสู่การปฏิบัติ',
                      items: [
                        { key: 's1_3_1', label: '1.3.1 มีการปฏิบัติตามกิจกรรมที่สอดคล้องกับแผนที่วางไว้' },
                      ]
                    },
                    {
                      sectionTitle: '1.4 การประเมินผล',
                      items: [
                        { key: 's1_4_1', label: '1.4.1 มีการประเมินผลที่ชัดเจนและสะท้อนให้เห็นการดูแลที่ต่อเนื่อง' },
                        { key: 's1_4_2', label: '1.4.2 ชื่อผู้บันทึกพร้อมตำแหน่ง' },
                      ]
                    }
                  ];
                  return formStructure1.map((group, gIdx) => (
                    <div key={gIdx} className="space-y-2 pl-2">
                      <h4 className="font-bold text-emerald-700 text-xs border-l-4 border-emerald-500 pl-2 py-0.5">
                        {group.sectionTitle}
                      </h4>
                      <div className="space-y-1.5 pl-2">
                        {group.items.map((subItem, sIdx) => {
                          const scoreValue = selectedAuditItem[subItem.key] ?? (Array.isArray(selectedAuditItem.audit_na_keys) && selectedAuditItem.audit_na_keys.includes(subItem.key) ? 'NA' : undefined);
                          if (scoreValue === undefined) return null;
                          return (
                            <div key={sIdx} className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2 p-3 sm:grid-cols-[minmax(0,1fr)_3rem_minmax(8rem,30%)] bg-white rounded-xl border border-gray-200 shadow-xs hover:border-gray-300 transition">
                              <span className="text-gray-800 font-medium pr-4">{subItem.label}</span>
                              <span className="bg-gray-50 px-3 py-1.5 rounded-lg font-bold text-gray-800 border border-gray-300 min-w-12 text-center">
                                {String(scoreValue)}
                              </span>
                              <div className="col-span-2 min-w-0 whitespace-pre-wrap break-words text-slate-600 sm:col-span-1">
                                <span className="block text-[10px] font-semibold">หมายเหตุ</span>
                                {questionNote(subItem.key)}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ));
                })()}
                {sectionNote(1)}
              </div>
              {/* ================= หมวดที่ 2 ================= */}
              <div className="space-y-4 pt-2">
                <h3 className="font-bold text-gray-900 text-sm border-b-2 border-emerald-600 pb-1.5 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                  2. การประเมินต่อเนื่อง (รวมถึงการวางแผนจำหน่าย และการให้สารน้ำ)
                </h3>
                {(() => {
                  const formStructure2 = [
                    {
                      sectionTitle: '2.1 เฝ้าระวังและควบคุมปัญหาวิกฤต/อาการรบกวนต่อเนื่อง',
                      items: [
                        { key: 's2_1_a', label: 'A : ประเมินสภาพในระบบที่ผิดปกติและที่เกี่ยวข้องอย่างต่อเนื่อง' },
                        { key: 's2_1_p', label: 'P : วางแผนการพยาบาล ระบุปัญหา สาเหตุ และกิจกรรมการพยาบาล' },
                        { key: 's2_1_i', label: 'I : มีการปฏิบัติตามกิจกรรมที่สอดคล้องกับแผนที่วางไว้' },
                        { key: 's2_1_e', label: 'E : มีการประเมินผลที่ชัดเจนและสะท้อนให้เห็นการดูแลที่ต่อเนื่อง' },
                        { key: 's2_1_name', label: 'ชื่อผู้บันทึกพร้อมตำแหน่ง' },
                      ]
                    },
                    {
                      sectionTitle: '2.2 ป้องกันภาวะแทรกซ้อนต่อเนื่อง',
                      items: [
                        { key: 's2_2_a', label: 'A : ประเมินสภาพต่อเนื่องเกี่ยวกับโอกาสเกิดภาวะแทรกซ้อน' },
                        { key: 's2_2_p', label: 'P : วางแผนการพยาบาล ป้องกันภาวะแทรกซ้อนต่อเนื่อง ระบุ ปัญหา สาเหตุ และกิจกรรมการพยาบาล' },
                        { key: 's2_2_i', label: 'I : มีการปฏิบัติตามกิจกรรมที่สอดคล้องกับแผนที่วางไว้' },
                        { key: 's2_2_e', label: 'E : มีการประเมินผลที่ชัดเจนและสะท้อนให้เห็นการดูแลที่ต่อเนื่อง' },
                        { key: 's2_2_name', label: 'ชื่อผู้บันทึกพร้อมตำแหน่ง' },
                      ]
                    },
                    {
                      sectionTitle: '2.3 ฟื้นฟูสภาพ',
                      items: [
                        { key: 's2_3_a', label: 'A : ประเมินสภาพต่อเนื่องเกี่ยวกับความต้องการและความสามารถในการฟื้นฟูสภาพ' },
                        { key: 's2_3_p', label: 'P : วางแผนการพยาบาล ฟื้นฟูสภาพ ระบุความต้องการและกิจกรรมการพยาบาล' },
                        { key: 's2_3_i', label: 'I : มีการปฏิบัติตามกิจกรรมที่สอดคล้องกับแผนที่วางไว้' },
                        { key: 's2_3_e', label: 'E : มีการประเมินผลที่ชัดเจนและสะท้อนให้เห็นการดูแลที่ต่อเนื่อง' },
                        { key: 's2_3_name', label: 'ชื่อผู้บันทึกพร้อมตำแหน่ง' },
                      ]
                    },
                    {
                      sectionTitle: '2.4 ประเมินความพร้อมของผู้ป่วยและญาติในการดูแลตนเอง',
                      items: [
                        { key: 's2_4_a', label: 'A : ประเมินความสามารถและการรับรู้ในการดูแลตนเองพร้อมทั้งระบุปัญหา/ความต้องการการดูแลต่อเนื่องที่บ้าน' },
                        { key: 's2_4_p', label: 'P : วางแผนการดูแลต่อเนื่องที่บ้าน' },
                        { key: 's2_4_i', label: 'I : มีการปฏิบัติตามแผนการดูแลต่อเนื่อง' },
                        { key: 's2_4_e', label: 'E : ประเมินผลการปฏิบัติตามแผนและปรับปรุงแผนอย่างสม่ำเสมอ' },
                        { key: 's2_4_name', label: 'ชื่อผู้บันทึกพร้อมตำแหน่ง' },
                      ]
                    }
                  ];
                  return formStructure2.map((group, gIdx) => (
                    <div key={gIdx} className="space-y-2 pl-2">
                      <h4 className="font-bold text-emerald-700 text-xs border-l-4 border-emerald-500 pl-2 py-0.5">
                        {group.sectionTitle}
                      </h4>
                      <div className="space-y-1.5 pl-2">
                        {group.items.map((subItem, sIdx) => {
                          const scoreValue = selectedAuditItem[subItem.key] ?? (Array.isArray(selectedAuditItem.audit_na_keys) && selectedAuditItem.audit_na_keys.includes(subItem.key) ? 'NA' : undefined);
                          if (scoreValue === undefined) return null;
                          return (
                            <div key={sIdx} className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2 p-3 sm:grid-cols-[minmax(0,1fr)_3rem_minmax(8rem,30%)] bg-white rounded-xl border border-gray-200 shadow-xs hover:border-gray-300 transition">
                              <span className="text-gray-800 font-medium pr-4">{subItem.label}</span>
                              <span className="bg-gray-50 px-3 py-1.5 rounded-lg font-bold text-gray-800 border border-gray-300 min-w-12 text-center">
                                {String(scoreValue)}
                              </span>
                              <div className="col-span-2 min-w-0 whitespace-pre-wrap break-words text-slate-600 sm:col-span-1">
                                <span className="block text-[10px] font-semibold">หมายเหตุ</span>
                                {questionNote(subItem.key)}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ));
                })()}
                {sectionNote(2)}
              </div>
              {/* ================= หมวดที่ 3 ================= */}
              <div className="space-y-4 pt-2">
                <h3 className="font-bold text-gray-900 text-sm border-b-2 border-emerald-600 pb-1.5 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                  3. การวางแผนจำหน่าย
                </h3>
                {(() => {
                  const items = [
                    { key: 's3_a', label: 'A : มีการเตรียมความพร้อมในการจำหน่ายโดยมีการคาดการณ์ ภาวะสุขภาพของผู้ป่วยก่อนจำหน่ายในด้านความสามารถ ทั้งด้านร่างกาย จิตใจ วิญญาณและสังคม' },
                    { key: 's3_p', label: 'P : กำหนดแผนการพยาบาลในการฟื้นฟูสภาพอย่างครอบคลุม' },
                    { key: 's3_i', label: 'I : มีการปฏิบัติตามแผนที่วางไว้ (สอนให้ความรู้และให้ปฏิบัติ)' },
                    { key: 's3_e', label: 'E : ประเมินผลตามความสามารถของผู้ป่วยและญาติในการดูแลตนเอง' },
                    { key: 's3_name', label: 'ชื่อผู้บันทึกพร้อมตำแหน่ง' },
                  ];
                  return (
                    <div className="space-y-1.5 pl-2">
                      {items.map((subItem, sIdx) => {
                        const scoreValue = selectedAuditItem[subItem.key] ?? (Array.isArray(selectedAuditItem.audit_na_keys) && selectedAuditItem.audit_na_keys.includes(subItem.key) ? 'NA' : undefined);
                        if (scoreValue === undefined) return null;
                        return (
                          <div key={sIdx} className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2 p-3 sm:grid-cols-[minmax(0,1fr)_3rem_minmax(8rem,30%)] bg-white rounded-xl border border-gray-200 shadow-xs hover:border-gray-300 transition">
                            <span className="text-gray-800 font-medium pr-4">{subItem.label}</span>
                            <span className="bg-gray-50 px-3 py-1.5 rounded-lg font-bold text-gray-800 border border-gray-300 min-w-12 text-center">
                              {String(scoreValue)}
                            </span>
                              <div className="col-span-2 min-w-0 whitespace-pre-wrap break-words text-slate-600 sm:col-span-1">
                                <span className="block text-[10px] font-semibold">หมายเหตุ</span>
                                {questionNote(subItem.key)}
                              </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
                {sectionNote(3)}
              </div>
              {/* ================= หมวดที่ 4 ================= */}
              <div className="space-y-4 pt-2">
                <h3 className="font-bold text-gray-900 text-sm border-b-2 border-emerald-600 pb-1.5 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                  4. การบันทึกวันจำหน่าย
                </h3>
                {(() => {
                  const items = [
                    { key: 's4_1', label: '4.1 มีการบันทึกสัญญาณชีพก่อนการจำหน่าย' },
                    { key: 's4_2', label: '4.2 มีการบันทึกสภาวะ/ปัญหาของผู้ป่วยที่ต้องดูแลอย่างต่อเนื่อง' },
                    { key: 's4_3', label: '4.3 มีการประเมินความพร้อมในการดูแลตนเองของผู้ป่วยก่อนจำหน่ายและให้คำแนะนำเพิ่มเติม' },
                    { key: 's4_4', label: '4.4 มีการบันทึกประเภทจำหน่าย' },
                    { key: 's4_5', label: '4.5 มีการบันทึก การส่งต่อ/ การนัดมาตรวจ' },
                    { key: 's4_6', label: '4.6 ชื่อผู้บันทึกพร้อมตำแหน่ง' },
                  ];
                  return (
                    <div className="space-y-1.5 pl-2">
                      {items.map((subItem, sIdx) => {
                        const scoreValue = selectedAuditItem[subItem.key] ?? (Array.isArray(selectedAuditItem.audit_na_keys) && selectedAuditItem.audit_na_keys.includes(subItem.key) ? 'NA' : undefined);
                        if (scoreValue === undefined) return null;
                        return (
                          <div key={sIdx} className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2 p-3 sm:grid-cols-[minmax(0,1fr)_3rem_minmax(8rem,30%)] bg-white rounded-xl border border-gray-200 shadow-xs hover:border-gray-300 transition">
                            <span className="text-gray-800 font-medium pr-4">{subItem.label}</span>
                            <span className="bg-gray-50 px-3 py-1.5 rounded-lg font-bold text-gray-800 border border-gray-300 min-w-12 text-center">
                              {String(scoreValue)}
                            </span>
                              <div className="col-span-2 min-w-0 whitespace-pre-wrap break-words text-slate-600 sm:col-span-1">
                                <span className="block text-[10px] font-semibold">หมายเหตุ</span>
                                {questionNote(subItem.key)}
                              </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
                {sectionNote(4)}
              </div>
              {/* ================= หมวดที่ 5 ================= */}
              <div className="space-y-4 pt-2">
                <h3 className="font-bold text-gray-900 text-sm border-b-2 border-emerald-600 pb-1.5 flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                  5. การให้สารน้ำ/ยาทางหลอดเลือดดำ
                </h3>
                {(() => {
                  const items = [
                    { key: 's5_1', label: '5.1 บันทึกเกี่ยวกับการให้ความรู้ผู้ป่วย/ญาติ ชนิดของสารน้ำ ตำแหน่งการแทงเข็ม ภาวะแทรกซ้อนและการจัดการ' },
                  ];
                  return (
                    <div className="space-y-1.5 pl-2">
                      {items.map((subItem, sIdx) => {
                        const scoreValue = selectedAuditItem[subItem.key] ?? (Array.isArray(selectedAuditItem.audit_na_keys) && selectedAuditItem.audit_na_keys.includes(subItem.key) ? 'NA' : undefined);
                        if (scoreValue === undefined) return null;
                        return (
                          <div key={sIdx} className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2 p-3 sm:grid-cols-[minmax(0,1fr)_3rem_minmax(8rem,30%)] bg-white rounded-xl border border-gray-200 shadow-xs hover:border-gray-300 transition">
                            <span className="text-gray-800 font-medium pr-4">{subItem.label}</span>
                            <span className="bg-gray-50 px-3 py-1.5 rounded-lg font-bold text-gray-800 border border-gray-300 min-w-12 text-center">
                              {String(scoreValue)}
                            </span>
                              <div className="col-span-2 min-w-0 whitespace-pre-wrap break-words text-slate-600 sm:col-span-1">
                                <span className="block text-[10px] font-semibold">หมายเหตุ</span>
                                {questionNote(subItem.key)}
                              </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
                {sectionNote(5)}
              </div>
              <div className="rounded-xl border border-slate-200 bg-slate-50 p-3">
                <strong>หมายเหตุ / ข้อเสนอแนะเพิ่มเติมภาพรวม</strong>
                <p className="mt-1 whitespace-pre-wrap break-words">{selectedAuditItem.notes || '—'}</p>
              </div>
            </div>
            {/* ปุ่มกดอนุมัติเฉพาะในหน้าต่างดูรายละเอียด */}
            <div className="flex justify-end items-center pt-3 border-t gap-2">
              <button
                onClick={() => setSelectedAuditItem(null)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                ปิดหน้าต่างนี้
              </button>
              {canApprove && selectedAuditItem.status === 'pending' && (
                <button
                  onClick={() => {
                    void handleApproval(selectedAuditItem);
                  }}
                  disabled={loading}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow cursor-pointer flex items-center gap-1"
                >
                  <CheckCircleIcon className="w-4 h-4" /> อนุมัติรายการนี้
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
// Special Audit records have JSON answers and must use the authorized server API.
function SpecialLRBatchReview({batchGroup,departmentName,canApprove,onClose,onApprove}: {
 batchGroup:BatchGroup;departmentName:string;canApprove:boolean;onClose:()=>void;
 onApprove:(type:string,month:string)=>void;
}) {
 const [editing,setEditing]=useState(false);
 const [busy,setBusy]=useState(false),[message,setMessage]=useState('');
 const busyRef=React.useRef(false);
 const [selectedId,setSelectedId]=useState(()=>String(batchGroup.items[0]?.id||''));
 const item=batchGroup.items.find(entry=>String(entry.id)===selectedId)||batchGroup.items[0];
 React.useEffect(()=>{
  const before=document.body.style.overflow;document.body.style.overflow='hidden';
  return()=>{document.body.style.overflow=before;};
 },[]);
 async function action(item:BatchItem) {
  if(busyRef.current || !item.id)return;
  const endpoint=item.status==='draft'?'submit':'approve';
  if(endpoint==='approve'&&!canApprove)return;
  busyRef.current=true;setBusy(true);setMessage('');
  try {
   const response=await fetch(`/api/audits/${encodeURIComponent(String(item.id))}/${endpoint}`,{method:'POST',credentials:'same-origin'});
   const result=await response.json().catch(()=>null);
   if(!response.ok)throw new Error(result?.error||`HTTP ${response.status}`);
   window.alert(endpoint==='approve'?'อนุมัติรายการสำเร็จ':'ส่งรายการแล้ว — รออนุมัติ');
   window.dispatchEvent(new Event('audit-records-updated'));
   onApprove(batchGroup.type,batchGroup.audit_month);onClose();
  }catch(error){setMessage(error instanceof Error?error.message:'ดำเนินการไม่สำเร็จ');}
  finally{busyRef.current=false;setBusy(false);}
 }
 if(!item || typeof document==='undefined')return null;
 const answers=(item.answers||{}) as Record<string,{score?:number;na?:boolean;note?:string}>;
 const config=isSpecialUnitForm(item.form_type)?specialUnitAuditForms[item.form_type]:null;
 const reviewGroups=config?.groups||lrAuditGroups;
 const headings=config?config.headings.map(h=>({id:h.id,label:h.title})):[{id:'1',label:'1. ระยะก่อนคลอด/ก่อนผ่าตัด'},{id:'2',label:'2. การพยาบาลระยะคลอด/ผ่าตัด'},{id:'3',label:'3. การส่งต่อ'}];
 const sectionId=groupSection;
 const statusText=item.status==='pending'?'รออนุมัติ':item.status==='approved'?'อนุมัติแล้ว':item.status==='draft'?'ฉบับร่าง':item.status||'-';
 return createPortal(<div role="dialog" aria-modal="true" aria-label="รายละเอียดคะแนนประเมิน" className="fixed inset-0 z-[2147483647] flex items-center justify-center bg-slate-950/60 p-2 sm:p-5">
  <div className="flex max-h-[94dvh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl bg-white px-4 shadow-2xl sm:px-6">
   <header className="flex shrink-0 items-center justify-between gap-3 border-b border-slate-700 py-5">
    <h3 className="text-base font-extrabold text-slate-800 sm:text-xl">📝 ฟอร์มรายละเอียดคะแนนประเมิน ({item.hn ? `HN: ${item.hn}` : `AN: ${item.reference_number||item.an||'-'}`})</h3>
    <button type="button" aria-label="ปิดหน้าต่าง" disabled={busy} onClick={onClose} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-slate-100 text-slate-400 hover:bg-slate-200 disabled:opacity-50"><XMarkIcon className="h-6 w-6" /></button>
   </header>
   <div className="min-h-0 flex-1 overflow-y-auto py-5 pr-2 sm:pr-4">
    {batchGroup.items.length>1&&<label className="mb-4 block text-sm font-semibold">เลือกรายการ<select disabled={busy} value={String(item.id)} onChange={event=>{setSelectedId(event.target.value);setMessage('');}} className="ml-3 rounded-lg border p-2">{batchGroup.items.map((entry,index)=><option key={String(entry.id||index)} value={String(entry.id)}>AN: {entry.reference_number||entry.an||'-'} · {entry.auditor_name||'-'}</option>)}</select></label>}
    <div className="mb-7 grid grid-cols-1 gap-x-6 gap-y-2 rounded-xl border border-blue-100 bg-blue-50 p-4 text-sm text-slate-700 sm:grid-cols-2">
     <p><strong>ผู้ประเมิน:</strong> {item.auditor_name||batchGroup.auditor_name||'-'}</p>
     <p><strong>วันที่ประเมิน:</strong> {item.audit_date||'-'}</p>
     <p><strong>งวดประจำเดือน:</strong> {item.audit_month||batchGroup.audit_month}</p>
     <p><strong>สถานะรายการ:</strong> <span className={item.status==='approved'?'font-bold text-emerald-700':'font-bold text-amber-600'}>{statusText}</span></p>
     <p className="sm:col-span-2"><strong>หน่วยงาน:</strong> {departmentName}</p>
    </div>
    {headings.map(heading=>{
     const groups=reviewGroups.filter(group=>sectionId(group.title)===heading.id);
     if(!groups.length)return null;
     return <section key={heading.id} className="mb-7">
      <h4 className="mb-5 flex items-center gap-3 border-b border-emerald-500 pb-3 font-bold text-slate-900"><span className="h-3 w-3 rounded-full bg-emerald-600" />{heading.label}</h4>
      {groups.map(group=><div key={group.title} className="mb-5 pl-2 sm:pl-3">
       <h5 className="mb-3 border-l-4 border-emerald-500 pl-3 text-sm font-bold text-emerald-800">{group.title}</h5>
       <div className="space-y-2 pl-1 sm:pl-3">{group.items.map((criterion,index)=>{
        const answer=answers[criterion.id];
        const number=group.title.split(' ')[0];
        return <div key={criterion.id} className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
         <div className="flex items-center justify-between gap-4"><p className="min-w-0 text-sm leading-6 text-slate-800">{!config&&sectionId(group.title)!=='3'&&<strong className="mr-1">{number}.{index+1}</strong>}{criterion.label}</p><span className="inline-flex min-h-10 min-w-16 shrink-0 items-center justify-center rounded-xl border border-slate-300 bg-slate-50 px-3 text-sm font-bold text-slate-800">{answer?.na?'NA':answer?.score??'—'}</span></div>
         {answer?.note&&<p className="mt-3 whitespace-pre-wrap border-t border-amber-100 pt-2 text-sm text-amber-800"><strong>ข้อบกพร่อง/หมายเหตุ:</strong> {answer.note}</p>}
        </div>;
       })}</div>
      </div>)}
     </section>;
    })}
    {item.notes&&<div className="rounded-xl bg-slate-50 p-4 text-sm text-slate-700"><strong>โรค / หมายเหตุ</strong><p className="mt-1 whitespace-pre-wrap">{String(item.notes).replace(/^\[(?:LR|DIALYSIS|ER|ANESTHESIA|HBOT)_DISEASE\]\s*/, 'โรค: ')}</p></div>}
   </div>
   {editing&&<PendingRecordEditor table="nso_special_audits" id={item.id!} onClose={()=>setEditing(false)} onSaved={()=>{setEditing(false);onApprove(batchGroup.type,batchGroup.audit_month);onClose();}}/>}
   <footer className="shrink-0 border-t border-slate-700 py-4">
    <p role="status" aria-live="polite" className="mb-2 text-sm text-red-700">{message}</p>
    {item.status==='pending'&&!canApprove&&<p className="mb-3 text-sm text-amber-700">รอหัวหน้าผู้มีสิทธิ์อนุมัติ ผู้บันทึกอนุมัติรายการตนเองไม่ได้</p>}
    <div className="flex flex-wrap items-center justify-end gap-3">{['pending','draft'].includes(item.status||'')&&<button type="button" disabled={busy} onClick={()=>setEditing(true)} className="rounded-xl border border-teal-700 px-4 py-3 text-sm font-bold text-teal-800">แก้ไขรายการนี้</button>}
     <button type="button" disabled={busy} onClick={onClose} className="rounded-2xl bg-slate-100 px-5 py-3 text-sm font-bold text-slate-700 hover:bg-slate-200 disabled:opacity-50">ปิดหน้าต่างนี้</button>
     {(item.status==='draft'||(item.status==='pending'&&canApprove))&&<button type="button" disabled={busy} onClick={()=>void action(item)} className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-bold text-white shadow-sm hover:bg-emerald-700 disabled:opacity-50"><CheckCircleIcon className="h-5 w-5" />{busy?'กำลังดำเนินการ…':item.status==='draft'?'ส่งรออนุมัติ':'อนุมัติรายการนี้'}</button>}
    </div>
   </footer>
  </div>
 </div>,document.body);
}
