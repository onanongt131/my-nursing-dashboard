'use client';

import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {wpItemsForWard} from '@/lib/wpIpdCriteria';
import {ipdAuditRequest} from '@/lib/ipdAuditClient';

interface WpQaModalProps {
  isOpen: boolean;
  onClose: () => void;
  departmentId: string | number;
  departmentName: string;
  supabase: any;
  onSuccess: () => void;
}



export default function WpQaModal({
  isOpen,
  onClose,
  departmentId,
  departmentName,
  supabase,
  onSuccess,
}: WpQaModalProps) {
  const [saving, setSaving] = useState(false);
  const [portalReady, setPortalReady] = useState(false);

  useEffect(() => { setPortalReady(true); }, []);

  useEffect(() => {
    if (!isOpen) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !saving) onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', onKeyDown);
    };
  }, [isOpen, onClose, saving]);
  const [auditMonth, setAuditMonth] = useState(new Date().toISOString().slice(0, 7)); // รูปแบบ YYYY-MM
  const [auditorName, setAuditorName] = useState('');
  
  // เก็บข้อมูลแต่ละหัวข้อ
  const wpQaItems = wpItemsForWard(departmentName);
  const [formData, setFormData] = useState<Record<string, { total_evaluated: string; total_practiced: string; unpracticed_reasons: string }>>({});

  if (!isOpen || !portalReady) return null;

  const handleChange = (id: string, field: string, value: string) => {
    setFormData(prev => {
      const currentItem = prev[id] || { total_evaluated: '', total_practiced: '', unpracticed_reasons: '' };
      const updatedItem = { ...currentItem, [field]: value };

      // ถ้าปรับจำนวนประเมินหรือปฏิบัติแล้วเท่ากัน ให้เคลียร์หมายเหตุทิ้ง
      if (field === 'total_evaluated' || field === 'total_practiced') {
        const evalVal = field === 'total_evaluated' ? value : currentItem.total_evaluated;
        const pracVal = field === 'total_practiced' ? value : currentItem.total_practiced;
        
        if (evalVal !== '' && pracVal !== '' && Number(evalVal) === Number(pracVal)) {
          updatedItem.unpracticed_reasons = '';
        }
      }

      return {
        ...prev,
        [id]: updatedItem
      };
    });
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!departmentId || saving) return;

    setSaving(true);

    try {
      // ตรวจสอบความถูกต้อง
      for (const item of wpQaItems) {
        const itemData = formData[item.id];
        
        // 1. ตรวจสอบว่ากรอกจำนวนประเมินหรือยัง
        if (!itemData || itemData.total_evaluated === '' || isNaN(Number(itemData.total_evaluated))) {
          alert(`กรุณากรอก "จำนวนประเมิน" เป็นตัวเลขให้ครบทุกหัวข้อ (${item.id})`);
          setSaving(false);
          return;
        }

        const evaluated = Number(itemData.total_evaluated);
        const practiced = Number(itemData.total_practiced || 0);

        // 2. ห้ามใส่จำนวนประเมินเป็น 0 (ต้องใส่จำนวน หรือถ้าใส่ 0 ต้องบังคับระบุเหตุผล)
        if (evaluated === 0) {
          alert(`หัวข้อ ${item.id}: ห้ามใส่จำนวนประเมินเป็น 0 กรุณาระบุจำนวนหรือใส่เหตุผลในช่องหมายเหตุ`);
          setSaving(false);
          return;
        }

        // 3. ถ้าจำนวนปฏิบัติไม่เท่ากับจำนวนประเมิน หรือประเมินเป็น 0 ต้องใส่เหตุผล
        if (evaluated !== practiced && (!itemData.unpracticed_reasons || itemData.unpracticed_reasons.trim() === '')) {
          alert(`หัวข้อ ${item.id}: กรุณาระบุ "สิ่งที่ไม่ได้ปฏิบัติ / หมายเหตุ" เนื่องจากจำนวนปฏิบัติไม่ตรงกับจำนวนประเมิน`);
          setSaving(false);
          return;
        }
      }

      // แปลงข้อมูลให้อยู่ในรูป Array สำหรับบันทึกลง Database
      const recordsToInsert = wpQaItems.map(item => {
        const itemData = formData[item.id] || { total_evaluated: '0', total_practiced: '0', unpracticed_reasons: '' };
        const evaluated = Number(itemData.total_evaluated) || 0;
        const practiced = Number(itemData.total_practiced) || 0;

        return {
          department_id: Number(departmentId),
          audit_month: auditMonth,
          wp_id: item.id,
          wp_name: item.name,
          total_evaluated: evaluated,
          total_practiced: practiced,
          unpracticed_reasons: evaluated !== practiced ? (itemData.unpracticed_reasons || null) : null,
          auditor_name: auditorName || null,
          status: 'pending',
        };
      });

      await ipdAuditRequest({action:'wp-save',department_id:Number(departmentId),audit_month:auditMonth,auditor_name:auditorName,rows:recordsToInsert});

      alert('บันทึกข้อมูลการประเมิน WP/QA ประจำเดือนสำเร็จ');
      onSuccess();
      onClose();
    } catch (error: any) {
      alert('เกิดข้อผิดพลาดในการบันทึก: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  return createPortal(
    <div role="presentation" className="fixed inset-0 z-[99999] flex items-center justify-center bg-black/65 p-2 sm:p-4">
      <div role="dialog" aria-modal="true" aria-label={`บันทึกการประเมิน WP/QA ${departmentName}`} className="bg-white rounded-2xl shadow-2xl max-w-6xl w-full h-[min(92dvh,1000px)] flex flex-col min-h-0 overflow-hidden">
        
        {/* Header */}
        <div className="bg-emerald-900 text-white px-5 py-3 flex shrink-0 justify-between items-center">
          <div>
            <h2 className="text-lg font-bold">บันทึกการประเมิน WP/QA</h2>
            <p className="text-xs text-emerald-200">หน่วยงาน: {departmentName}</p>
          </div>
          <button onClick={onClose} className="text-white hover:text-gray-200 text-xl font-bold">✕</button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="flex-1 min-h-0 overflow-y-auto overscroll-contain p-4 sm:p-6 space-y-6">
          
          {/* ข้อมูลส่วนหัว: เดือนและชื่อผู้ประเมิน */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-emerald-50/50 p-4 rounded-xl border border-emerald-100">
            <div>
              <label className="block text-sm font-semibold text-emerald-900 mb-1">ประจำเดือน (Month)</label>
              <input 
                type="month" 
                value={auditMonth}
                onChange={(e) => setAuditMonth(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-emerald-900 mb-1">ชื่อผู้ประเมิน / ผู้บันทึก</label>
              <input 
                type="text" 
                placeholder="ระบุชื่อ-นามสกุลผู้ประเมิน"
                value={auditorName}
                onChange={(e) => setAuditorName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
          </div>

          {/* ตารางหัวข้อ WP/QA */}
          <div className="border border-emerald-100 rounded-xl overflow-x-auto shadow-sm">
            <table className="w-full min-w-[850px] text-left border-collapse text-sm">
              <thead>
                <tr className="bg-emerald-100/70 text-emerald-950 font-bold border-b border-emerald-200">
                  <th className="p-3 w-[40%]">หัวข้อ WP / QA</th>
                  <th className="p-3 w-[15%] text-center">จำนวนประเมิน</th>
                  <th className="p-3 w-[15%] text-center">จำนวนปฏิบัติ</th>
                  <th className="p-3 w-[30%]">สิ่งที่ไม่ได้ปฏิบัติ / หมายเหตุ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-gray-700">
                {wpQaItems.map((item) => {
                  const evaluated = Number(formData[item.id]?.total_evaluated) || 0;
                  const practiced = Number(formData[item.id]?.total_practiced) || 0;
                  const isNotEqual = formData[item.id]?.total_evaluated !== '' && formData[item.id]?.total_practiced !== '' && evaluated !== practiced;

                  return (
                    <tr key={item.id} className="hover:bg-emerald-50/20 transition-colors">
                      <td className="p-3">
                        <div className="font-bold text-emerald-900 text-xs">{item.id}</div>
                        <div className="text-xs text-gray-600 mt-0.5">{item.name}</div>
                      </td>
                      <td className="p-3 text-center">
                        <input 
                          type="number" 
                          min="1"
                          placeholder="กรอก > 0"
                          value={formData[item.id]?.total_evaluated ?? ''}
                          onChange={(e) => handleChange(item.id, 'total_evaluated', e.target.value)}
                          className="w-24 mx-auto border border-gray-300 rounded p-1 text-center text-sm font-semibold"
                          required
                        />
                      </td>
                      <td className="p-3 text-center">
                        <input 
                          type="number" 
                          min="0"
                          placeholder="0"
                          value={formData[item.id]?.total_practiced ?? ''}
                          onChange={(e) => handleChange(item.id, 'total_practiced', e.target.value)}
                          className="w-20 mx-auto border border-gray-300 rounded p-1 text-center text-sm font-semibold text-green-700"
                        />
                      </td>
                      <td className="p-3">
                        {isNotEqual || evaluated === 0 ? (
                          <input 
                            type="text" 
                            placeholder="ระบุเหตุผล/สิ่งที่ไม่ได้ปฏิบัติ..."
                            value={formData[item.id]?.unpracticed_reasons || ''}
                            onChange={(e) => handleChange(item.id, 'unpracticed_reasons', e.target.value)}
                            className="w-full border border-amber-300 bg-amber-50/30 rounded p-1.5 text-xs focus:ring-2 focus:ring-emerald-500 animate-fadeIn"
                            required
                          />
                        ) : (
                          <span className="text-xs text-gray-400 italic">- ครบถ้วน / ปกติ -</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Footer Actions */}
          <div className="sticky bottom-0 z-10 -mx-4 sm:-mx-6 -mb-4 sm:-mb-6 bg-white border-t border-gray-200 p-3 sm:p-4 flex justify-end gap-3 shadow-[0_-5px_14px_rgba(0,0,0,0.06)]">
            <button 
              type="button" 
              onClick={onClose}
              className="px-5 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-100 font-medium text-sm transition-colors"
            >
              ยกเลิก
            </button>
            <button 
              type="submit" 
              disabled={saving}
              className="px-6 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg font-bold text-sm shadow transition-colors disabled:opacity-50"
            >
              {saving ? 'กำลังบันทึก...' : 'บันทึกข้อมูล WP/QA'}
            </button>
          </div>

        </form>
      </div>
    </div>
  , document.body);
}