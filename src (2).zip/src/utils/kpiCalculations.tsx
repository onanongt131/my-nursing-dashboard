// src/utils/kpiCalculations.ts
import { ReactNode } from 'react';

export type KpiType = 'percent' | 'rate' | 'count';

// --- 1. กลุ่มคำนวณค่าพื้นฐาน ---
export const calculateEntryValue = (entry: any, kpiType: KpiType): number | string => {
  if (!entry) return "-";

  // 1. ถ้าเป็น Percent หรือ Rate ที่มีสูตร (มี numerator/denominator) ให้คำนวณตามสูตร
  if (kpiType === 'percent' && entry.numerator != null && entry.denominator > 0) {
    return Number(((entry.numerator / entry.denominator) * 100).toFixed(2));
  }
  if (kpiType === 'rate' && entry.numerator != null && entry.denominator > 0) {
    return Number(((entry.numerator / entry.denominator) * 1000).toFixed(2));
  }

  // 2. ถ้าเป็นประเภท count ให้ดึงค่ามาตรงๆ โดยไม่บังคับทศนิยม
  const finalValue = entry.value != null ? entry.value : entry.numerator;
  if (finalValue == null) return "-";

  const numVal = Number(finalValue);
  // ถ้าเป็น count และเป็นจำนวนเต็ม ให้คืนค่าเป็นจำนวนเต็มปกติ ไม่เติม .00
  if (kpiType === 'count') {
    return numVal;
  }

  return Number(numVal.toFixed(2)) || 0;
};

export const calculateYearlySummary = (entries: any[], year: number, type: KpiType): string | number => {
  const yearlyEntries = entries.filter(e => e.year === year);
  if (yearlyEntries.length === 0) return "-";

  const sum = yearlyEntries.reduce((acc, curr) => {
    const val = calculateEntryValue(curr, type);
    return acc + (typeof val === 'number' ? val : 0);
  }, 0);

  // ถ้าเป็น count ให้คืนค่าผลรวม (SUM) ทันที ไม่หาค่าเฉลี่ย
  if (type === 'count') {
    return sum;
  }

  // สำหรับ percent หรือ rate ใช้การหาค่าเฉลี่ยตามเดิม
  const avg = sum / yearlyEntries.length;
  if (Number.isInteger(avg)) {
    return avg.toString();
  }

  return avg.toFixed(2);
};
  

// --- 2. กลุ่มจัดการสถานะและการแสดงผล ---
// --- 2. กลุ่มจัดการสถานะและการแสดงผล ---
export const checkStatus = (value: number, target: number, operator: string, isHigherBetter: boolean = true): boolean => {
  // หากเป็นตัวชี้วัดที่ค่าต่ำคือดี (เช่น อุบัติการณ์) ให้กลับผลลัพธ์
  const passed = (() => {
    switch (operator) {
      case '>': return value > target;
      case '>=': return value >= target;
      case '<': return value < target;
      case '<=': return value <= target;
      default: return value >= target;
    }
  })();
  
  return isHigherBetter ? passed : !passed;
};

// --- 2. กลุ่มจัดการสถานะและการแสดงผล ---
// --- 2. กลุ่มจัดการสถานะและการแสดงผล ---
export const getYearlyTrend = (
  entries: any[], 
  kpiType: KpiType, 
  operator: string, 
  target?: number | string, 
  currentYear: number = 2570
): React.ReactNode => {
  const prevYear = currentYear - 1;
  const avgCurrent = calculateYearlySummary(entries, currentYear, kpiType);
  const avgPrev = calculateYearlySummary(entries, prevYear, kpiType);

  if (avgCurrent === "-" || avgPrev === "-") return "-";

  const valCurrent = Number(avgCurrent);
  const valPrev = Number(avgPrev);

  // กรณีค่าเท่ากัน (คงที่)
  if (valCurrent === valPrev) {
    return (
      <span className="inline-flex items-center gap-1 font-medium text-xs text-blue-500 whitespace-nowrap">
        <span>o</span> <span>คงที่</span>
      </span>
    );
  }

  const safeOperator = operator ? operator.trim() : '';
  let isLessIsBetter = false;

  if (safeOperator) {
    isLessIsBetter = safeOperator.includes('<');
  } else if (target !== undefined && target !== null) {
    const numTarget = Number(target);
    if (numTarget === 0) {
      isLessIsBetter = true;  
    } else if (numTarget === 100) {
      isLessIsBetter = false; 
    }
  }

  const isImproved = isLessIsBetter ? valCurrent < valPrev : valCurrent > valPrev;

  if (isImproved) {
    // ดีขึ้น (สีเขียว)
    return (
      <span className="inline-flex items-center gap-1 font-medium text-xs text-green-600 whitespace-nowrap">
        <span>▲</span> <span>ดีขึ้น</span>
      </span>
    );
  } else {
    // เฝ้าระวัง (สีแดง)
    return (
      <span className="inline-flex items-center gap-1 font-medium text-xs text-red-500 whitespace-nowrap">
        <span>▼</span> <span>เฝ้าระวัง</span>
      </span>
    );
  }
};

// --- 3. กลุ่มจัดการสถานะปุ่ม (Alert/Status) ---
const monthMap: Record<string, number> = {
  'Jan': 1, 'Feb': 2, 'Mar': 3, 'Apr': 4, 'May': 5, 'Jun': 6,
  'Jul': 7, 'Aug': 8, 'Sep': 9, 'Oct': 10, 'Nov': 11, 'Dec': 12
};

export const getButtonStyle = (entries: any[], frequency: 'monthly' | 'quarterly' | 'yearly'): string => {
  if (!entries || entries.length === 0) return "bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-lg text-xs transition-all shadow-sm";
  
  const sorted = [...entries].sort((a, b) => (b.year - a.year) || (monthMap[b.month] - monthMap[a.month]));
  const latest = sorted[0];
  const currentYear = 2569;
  const currentMonth = 7;

  if (frequency === 'monthly') {
    const diff = (currentYear - Number(latest.year)) * 12 + (currentMonth - (monthMap[latest.month] || 1));
    if (diff <= 1) return "bg-purple-300 hover:bg-purple-400 text-white px-3 py-1 rounded-lg text-xs transition-all shadow-sm";
    if (diff === 2) return "bg-purple-600 hover:bg-purple-700 text-white px-3 py-1 rounded-lg text-xs transition-all shadow-sm";
    return "bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-lg text-xs transition-all shadow-sm";
  }

  if (frequency === 'quarterly') {
    const diffQ = (currentYear - Number(latest.year)) * 4 + (Math.ceil(currentMonth / 3) - Math.ceil((monthMap[latest.month] || 1) / 3));
    return diffQ <= 1 ? "bg-purple-300 hover:bg-purple-400 text-white px-3 py-1 rounded-lg text-xs transition-all shadow-sm" : "bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-lg text-xs transition-all shadow-sm";
  }

  return Number(latest.year) >= currentYear 
    ? "bg-purple-300 hover:bg-purple-400 text-white px-3 py-1 rounded-lg text-xs transition-all shadow-sm" 
    : "bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-lg text-xs transition-all shadow-sm";
};
